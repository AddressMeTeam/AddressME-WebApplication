from django import forms
from .models import ResidentProfile

class ResidentInfoForm(forms.ModelForm):
    """
    Form for residents to submit or update their address and personal info.
    """
    class Meta:
        model = ResidentProfile
        fields = [
            'first_name', 'last_name', 'id_number', 'phone_number',
            'settlement', 'unit_number', 'postal_code', 'is_owner',
            'municipality', 'ward_number', 'councillor_name'
        ]
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'id_number': forms.TextInput(attrs={'class': 'form-control'}),
            'phone_number': forms.TextInput(attrs={'class': 'form-control'}),
            'settlement': forms.TextInput(attrs={'class': 'form-control'}),
            'unit_number': forms.TextInput(attrs={'class': 'form-control'}),
            'postal_code': forms.TextInput(attrs={'class': 'form-control'}),
            'municipality': forms.TextInput(attrs={'class': 'form-control'}),
            'ward_number': forms.NumberInput(attrs={'class': 'form-control'}),
            'councillor_name': forms.TextInput(attrs={'class': 'form-control'}),
        }
        labels = {
            'first_name': 'First Name',
            'last_name': 'Last Name',
            'id_number': 'ID Number',
            'phone_number': 'Phone Number',
            'settlement': 'Settlement/Area Name',
            'unit_number': 'Unit/House Number',
            'postal_code': 'Postal Code',
            'is_owner': 'Are you the property owner?',
            'municipality': 'Municipality',
            'ward_number': 'Ward Number',
            'councillor_name': 'Ward Councillor Name',
        }