from django.urls import path
from . import views

app_name = 'residents'

urlpatterns = [
    path('dashboard/', views.dashboard, name='dashboard'),
    path('profile/', views.profile_settings, name='profile'),
    path('resident-form/', views.resident_form, name='resident_form'),
    path('application-status/', views.application_status, name='application_status'),
    path('schedule-interview/', views.schedule_interview, name='schedule_interview'),
    path('proof-of-address/', views.proof_of_address, name='proof_of_address'),
]