from django.contrib import admin
from .models import ResidentProfile

@admin.register(ResidentProfile)
class ResidentProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'first_name', 'last_name', 'settlement', 'municipality', 'is_verified', 'created_at')
    list_filter = ('is_verified', 'is_owner', 'municipality', 'created_at')
    search_fields = ('user__username', 'first_name', 'last_name', 'id_number', 'settlement', 'municipality')
    readonly_fields = ('created_at', 'updated_at')
    
    fieldsets = (
        ('User Information', {
            'fields': ('user', 'first_name', 'last_name', 'id_number', 'phone_number')
        }),
        ('Address Details', {
            'fields': ('settlement', 'unit_number', 'postal_code', 'is_owner')
        }),
        ('Administrative', {
            'fields': ('municipality', 'ward_number', 'councillor_name')
        }),
        ('Photos', {
            'fields': ('id_photo_path', 'face_photo_path')
        }),
        ('Status', {
            'fields': ('is_verified',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def get_full_address(self, obj):
        return obj.get_full_address()
    get_full_address.short_description = 'Full Address'