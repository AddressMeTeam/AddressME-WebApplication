from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import ResidentProfile
from .forms import ResidentInfoForm
from apps.applications.models import AddressApplication

@login_required
def dashboard(request):
    try:
        resident_info = ResidentProfile.objects.get(user=request.user)
        
        # Get applications (similar to Flask prototype)
        approved_application = AddressApplication.objects.filter(
            applicant=request.user,
            status='approved'
        ).order_by('-updated_at').first()
        
        pending_application = AddressApplication.objects.filter(
            applicant=request.user,
            status__in=['pending', 'leader_approved', 'interview_scheduled', 'interview_completed', 'rejected']
        ).order_by('-created_at').first()
        
        return render(request, 'residents/dashboard.html', {
            'resident_info': resident_info,
            'approved_application': approved_application,
            'pending_application': pending_application
        })
    except ResidentProfile.DoesNotExist:
        messages.info(request, 'Please complete your resident information first.')
        return redirect('residents:resident_form')

@login_required
def profile_settings(request):
    try:
        resident_info = ResidentProfile.objects.get(user=request.user)
        return render(request, 'residents/profile_settings.html', {'resident_info': resident_info})
    except ResidentProfile.DoesNotExist:
        return redirect('residents:resident_form')

@login_required
def resident_form(request):
    try:
        resident_info = ResidentProfile.objects.get(user=request.user)
        form = ResidentInfoForm(instance=resident_info)
    except ResidentProfile.DoesNotExist:
        form = ResidentInfoForm()
    
    if request.method == 'POST':
        try:
            resident_info = ResidentProfile.objects.get(user=request.user)
            form = ResidentInfoForm(request.POST, instance=resident_info)
        except ResidentProfile.DoesNotExist:
            form = ResidentInfoForm(request.POST)
        
        if form.is_valid():
            resident_info = form.save(commit=False)
            resident_info.user = request.user
            resident_info.save()
            
            # Create application if it doesn't exist (matching Flask prototype)
            existing_application = AddressApplication.objects.filter(applicant=request.user).first()
            if not existing_application:
                application = AddressApplication.objects.create(
                    applicant=request.user,
                    status='pending'
                )
                messages.success(request, 'Your information has been saved and application submitted successfully!')
            else:
                messages.success(request, 'Your information has been updated successfully!')
            
            return redirect('residents:dashboard')
    
    return render(request, 'residents/resident_form.html', {'form': form})

@login_required
def application_status(request):
    applications = AddressApplication.objects.filter(applicant=request.user).order_by('-created_at')
    return render(request, 'residents/application_status.html', {'applications': applications})

@login_required
def schedule_interview(request):
    # Placeholder for interview scheduling functionality
    return render(request, 'residents/schedule_interview.html')

@login_required
def proof_of_address(request):
    # Placeholder for proof of address functionality
    return render(request, 'residents/proof_of_address.html')
