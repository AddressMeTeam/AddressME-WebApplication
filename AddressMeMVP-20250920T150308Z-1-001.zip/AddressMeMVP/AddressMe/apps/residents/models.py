from django.db import models
from django.conf import settings

class ResidentProfile(models.Model):
    """
    Stores detailed resident information for address verification.
    Linked to CustomUser via OneToOneField.
    """
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    
    # Personal Information (matching Flask prototype exactly)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    id_number = models.CharField(max_length=20, unique=True)
    phone_number = models.CharField(max_length=20)
    
    # Address Information
    settlement = models.CharField(max_length=100)
    unit_number = models.CharField(max_length=20)
    postal_code = models.CharField(max_length=10)
    is_owner = models.BooleanField(default=False)
    
    # Administrative Details
    municipality = models.CharField(max_length=100)
    ward_number = models.IntegerField()
    councillor_name = models.CharField(max_length=100)
    
    # Photo paths (matching Flask prototype)
    id_photo_path = models.CharField(max_length=200, blank=True, default='')
    face_photo_path = models.CharField(max_length=200, blank=True, default='')
    
    # Status
    is_verified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.settlement}"

    def get_full_address(self):
        return f"{self.unit_number}, {self.settlement}, {self.municipality}, {self.postal_code}"

# Keep this for backwards compatibility
ResidentInfo = ResidentProfile