from django.db import models
from django.conf import settings

class AddressApplication(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('leader_approved', 'Leader Approved'),
        ('interview_scheduled', 'Interview Scheduled'),
        ('interview_completed', 'Interview Completed'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    
    applicant = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='applications')
    leader = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='leader_applications')
    officer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='officer_applications')
    status = models.CharField(max_length=30, choices=STATUS_CHOICES, default='pending')
    leader_notes = models.TextField(blank=True)
    officer_notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Application by {self.applicant.username} - {self.status}"

class Appointment(models.Model):
    STATUS_CHOICES = [
        ('scheduled', 'Scheduled'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ]
    
    application = models.ForeignKey(AddressApplication, on_delete=models.CASCADE)
    resident = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='resident_appointments')
    officer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='officer_appointments')
    appointment_date = models.DateTimeField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='scheduled')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Appointment for {self.resident.username} on {self.appointment_date}"

class AddressCertificate(models.Model):
    application = models.OneToOneField(AddressApplication, on_delete=models.CASCADE)
    certificate_number = models.CharField(max_length=50, unique=True)
    issue_date = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"Certificate {self.certificate_number}"