from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def application_list(request):
    return render(request, 'applications/list.html')

@login_required
def create_application(request):
    return render(request, 'applications/create.html')

