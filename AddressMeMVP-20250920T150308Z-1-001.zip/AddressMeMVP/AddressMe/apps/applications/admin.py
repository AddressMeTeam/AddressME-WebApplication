from django.contrib import admin
from .models import AddressApplication, Appointment, AddressCertificate

@admin.register(AddressApplication)
class AddressApplicationAdmin(admin.ModelAdmin):
    list_display = ('applicant', 'status', 'leader', 'officer', 'created_at', 'updated_at')
    list_filter = ('status', 'created_at')
    search_fields = ('applicant__username', 'applicant__full_name')
    readonly_fields = ('created_at', 'updated_at')
    
    fieldsets = (
        ('Application Info', {
            'fields': ('applicant', 'status')
        }),
        ('Assignment', {
            'fields': ('leader', 'officer')
        }),
        ('Notes', {
            'fields': ('leader_notes', 'officer_notes')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('resident', 'officer', 'appointment_date', 'status', 'created_at')
    list_filter = ('status', 'appointment_date', 'created_at')
    search_fields = ('resident__username', 'officer__username')

@admin.register(AddressCertificate)
class AddressCertificateAdmin(admin.ModelAdmin):
    list_display = ('certificate_number', 'application', 'issue_date', 'is_active')
    list_filter = ('is_active', 'issue_date')
    search_fields = ('certificate_number', 'application__applicant__username')