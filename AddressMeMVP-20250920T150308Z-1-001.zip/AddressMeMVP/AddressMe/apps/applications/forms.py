from django import forms
from .models import AddressApplication

class AddressApplicationForm(forms.ModelForm):
    class Meta:
        model = AddressApplication
        fields = ('current_address', 'requested_address', 'reason')
        widgets = {
            'current_address': forms.Textarea(attrs={'rows': 3}),
            'requested_address': forms.Textarea(attrs={'rows': 3}),
            'reason': forms.Textarea(attrs={'rows': 4}),
        }