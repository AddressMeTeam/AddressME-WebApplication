from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LogoutView
from django.contrib import messages
from django.views.decorators.http import require_http_methods
from .models import CustomUser

def home(request):
    return render(request, 'index.html')

@require_http_methods(["GET", "POST"])
def register_view(request):
    """
    Resident registration view.
    Only allows creation of 'resident' user_type.
    """
    if request.method == 'POST':
        full_name = request.POST.get('full_name')
        username = request.POST.get('username')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        
        # Validation
        if password1 != password2:
            messages.error(request, 'Passwords do not match.')
            return render(request, 'accounts/register.html')
        
        if CustomUser.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists.')
            return render(request, 'accounts/register.html')
            
        if CustomUser.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists.')
            return render(request, 'accounts/register.html')
        
        # Create user
        user = CustomUser.objects.create_user(
            username=username,
            email=email,
            password=password1,
            full_name=full_name,
            user_type='resident'
        )
        
        login(request, user)
        messages.success(request, f'Account created successfully for {full_name}!')
        return redirect('residents:resident_form')
    
    return render(request, 'accounts/register.html')

@require_http_methods(["GET", "POST"])
def login_view(request):
    """
    Login view for all user types.
    Redirects to appropriate dashboard based on user_type.
    """
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            
            # Redirect based on user type
            if user.user_type == 'resident':
                return redirect('residents:dashboard')
            elif user.user_type == 'leader':
                if hasattr(user, 'leaderprofile') and user.leaderprofile.is_active:
                    return redirect('leaders:dashboard')
                else:
                    messages.warning(request, 'Your leader account is pending approval.')
                    return redirect('accounts:home')
            elif user.user_type == 'police':
                if hasattr(user, 'policeprofile') and user.policeprofile.is_active:
                    return redirect('police:dashboard')
                else:
                    messages.warning(request, 'Your police officer account is pending approval.')
                    return redirect('accounts:home')
        else:
            messages.error(request, 'Invalid username or password.')
    
    return render(request, 'accounts/login.html')

class CustomLogoutView(LogoutView):
    template_name = 'accounts/logout.html'
    
    def dispatch(self, request, *args, **kwargs):
        messages.success(request, 'You have been logged out successfully.')
        return super().dispatch(request, *args, **kwargs)