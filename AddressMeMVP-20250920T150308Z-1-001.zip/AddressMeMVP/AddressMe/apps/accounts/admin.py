from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser

@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        ('Additional Info', {'fields': ('user_type', 'full_name', 'is_verified', 'is_onboarded_by_admin')}),
    )
    list_display = ('username', 'email', 'full_name', 'user_type', 'is_onboarded_by_admin', 'is_verified', 'is_active')
    list_filter = ('user_type', 'is_onboarded_by_admin', 'is_verified', 'is_active')
    search_fields = ('username', 'email', 'full_name')
    
    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        if obj is None: 
            form.base_fields['user_type'].initial = 'resident'
        return form