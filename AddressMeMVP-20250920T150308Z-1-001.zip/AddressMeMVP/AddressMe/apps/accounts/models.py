from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    USER_TYPE_CHOICES = [
        ('resident', 'Resident'),
        ('leader', 'Leader'),
        ('police', 'Police Officer'),
    ]
    
    user_type = models.CharField(
        max_length=20,
        choices=USER_TYPE_CHOICES,
        default='resident'
    )
    full_name = models.CharField(max_length=100, blank=True, default='')
    is_verified = models.BooleanField(default=False)
    is_onboarded_by_admin = models.BooleanField(default=False)
    
    def save(self, *args, **kwargs):
        # Leaders and police are always onboarded by admin
        if self.user_type in ['leader', 'police']:
            self.is_onboarded_by_admin = True
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.username} ({self.user_type})"