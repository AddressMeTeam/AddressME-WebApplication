from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def dashboard(request):
    return render(request, 'police/dashboard.html')

@login_required
def verification_queue(request):
    return render(request, 'police/verification_queue.html')
