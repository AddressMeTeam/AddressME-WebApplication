from django import forms
from .models import PoliceProfile

class PoliceProfileForm(forms.ModelForm):
    class Meta:
        model = PoliceProfile
        fields = ['badge_number', 'rank', 'station']
        widgets = {
            'badge_number': forms.TextInput(attrs={'class': 'form-control'}),
            'rank': forms.TextInput(attrs={'class': 'form-control'}),
            'station': forms.TextInput(attrs={'class': 'form-control'}),
        }