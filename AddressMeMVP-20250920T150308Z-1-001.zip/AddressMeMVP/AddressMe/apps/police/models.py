from django.db import models
from django.conf import settings

class PoliceProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    badge_number = models.CharField(max_length=20, unique=True)
    station = models.CharField(max_length=200)
    rank = models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.username} - {self.rank}"

# Keep PoliceInfo as an alias for backwards compatibility
PoliceInfo = PoliceProfile