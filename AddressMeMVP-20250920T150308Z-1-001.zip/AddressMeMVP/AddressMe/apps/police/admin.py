from django.contrib import admin
from .models import PoliceProfile

@admin.register(PoliceProfile)
class PoliceProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'badge_number', 'station', 'rank', 'is_active', 'created_at')
    list_filter = ('is_active', 'created_at', 'rank')
    search_fields = ('user__username', 'badge_number', 'station')
    readonly_fields = ('created_at', 'updated_at')
    
    fieldsets = (
        ('User Information', {
            'fields': ('user',)
        }),
        ('Police Details', {
            'fields': ('badge_number', 'rank', 'station')
        }),
        ('Status', {
            'fields': ('is_active',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )