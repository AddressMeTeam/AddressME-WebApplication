from django import forms
from .models import LeaderProfile

class LeaderProfileForm(forms.ModelForm):
    class Meta:
        model = LeaderProfile
        fields = ['position', 'jurisdiction']
        widgets = {
            'position': forms.TextInput(attrs={'class': 'form-control'}),
            'jurisdiction': forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}),
        }