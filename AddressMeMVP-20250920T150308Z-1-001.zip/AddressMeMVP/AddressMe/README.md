# AddressMeMVP

## Overview

A Django web app for address verification with three user types:
- **Residents**: Self-register, submit address applications, view status.
- **Leaders**: Onboarded by admin, review/approve applications.
- **Police**: Onboarded by admin, conduct interviews and verification.

## Setup

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
2. Add correct details for your environment in a `.env`.
3. Create a PostgreSQL database and user.
4. Run migrations:
   ```
   python manage.py migrate
   ```
5. Create a superuser:
   ```
   python manage.py createsuperuser
   ```
6. Run the server:
   ```
   python manage.py runserver
   ```

## Notes

- Only residents can sign up via the website.
- Leaders and police are created via Django admin.
- All sensitive settings are in `.env`.

## Project Structure

- `apps/accounts`: Custom user model and authentication.
- `apps/residents`: Resident profile and dashboard.
- `apps/leaders`: Leader dashboard and application review.
- `apps/police`: Police dashboard and verification.
- `apps/applications`: Address application workflow.

## Important Notices

- **Security:**  
  This project currently has no advanced security settings (such as HTTPS, secure session/cookie settings, or production-level hardening). **It is not production ready.** Please review and implement appropriate security measures before deploying to a live environment.

- **Interview Conference System:**  
  The interview conference/meeting system for resident verification is **not yet implemented**. This feature will need to be developed and integrated if required for your workflow.

- **Testing:**  
  This website has **not been fully tested** as it was still in the development phase. Please thoroughly test all features and workflows before considering production use.

## Contact

For questions, contact the previous developer or check the code comments.