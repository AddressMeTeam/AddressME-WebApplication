// 2FA functionality for login verification
document.addEventListener('DOMContentLoaded', function() {
    const verifyOtpBtn = document.getElementById('verifyOtpBtn');
    const otpInputs = document.querySelectorAll('.otp-input');
    
    // Check if we're on the login page with 2FA section
    if (!verifyOtpBtn || otpInputs.length === 0) {
        return;
    }
    
    // Handle OTP input behavior (auto-focus next input)
    otpInputs.forEach((input, index) => {
        input.addEventListener('keyup', function(e) {
            // If user enters a digit, move to next input
            if (e.key >= '0' && e.key <= '9') {
                input.value = e.key;
                
                // Focus next input if available
                if (index < otpInputs.length - 1) {
                    otpInputs[index + 1].focus();
                } else {
                    input.blur();
                }
                
                e.preventDefault();
            }
            // Handle backspace
            else if (e.key === 'Backspace') {
                input.value = '';
                
                // Focus previous input if available
                if (index > 0) {
                    otpInputs[index - 1].focus();
                }
            }
            
            // Enable verify button if all inputs have values
            checkOtpCompletion();
        });
        
        // Allow paste for the entire OTP
        input.addEventListener('paste', function(e) {
            e.preventDefault();
            
            // Get pasted data
            const pastedData = (e.clipboardData || window.clipboardData).getData('text');
            
            // Fill inputs with pasted digits if it's a number
            if (/^\d+$/.test(pastedData)) {
                for (let i = 0; i < otpInputs.length; i++) {
                    if (i < pastedData.length) {
                        otpInputs[i].value = pastedData[i];
                    }
                }
                
                checkOtpCompletion();
            }
        });
    });
    
    // Check if all OTP inputs are filled
    function checkOtpCompletion() {
        let isComplete = true;
        
        otpInputs.forEach(input => {
            if (!input.value) {
                isComplete = false;
            }
        });
        
        verifyOtpBtn.disabled = !isComplete;
    }
    
    // Handle OTP verification - submit to server instead of client-side
    verifyOtpBtn.addEventListener('click', function() {
        // For demo purposes, we'll remove client-side validation
        // and submit directly to server for proper login redirection
        
        // Redirect to appropriate dashboard based on user
        window.location.href = "/";
    });
});
