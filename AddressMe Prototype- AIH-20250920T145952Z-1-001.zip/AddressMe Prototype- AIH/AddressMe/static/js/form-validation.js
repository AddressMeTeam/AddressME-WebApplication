// Form validation utilities

// Function to validate full name
function validateFullName(input) {
    const value = input.value.trim();
    const errorElement = input.nextElementSibling;
    
    if (value.length < 2) {
        errorElement.textContent = 'Please enter your full name';
        return false;
    }
    
    if (!/^[a-zA-Z\s\-']+$/.test(value)) {
        errorElement.textContent = 'Name should contain only letters, spaces, hyphens and apostrophes';
        return false;
    }
    
    errorElement.textContent = '';
    return true;
}

// Function to validate email
function validateEmail(input) {
    const value = input.value.trim();
    const errorElement = input.nextElementSibling;
    
    if (!value) {
        errorElement.textContent = 'Email is required';
        return false;
    }
    
    // Basic email validation regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(value)) {
        errorElement.textContent = 'Please enter a valid email address';
        return false;
    }
    
    errorElement.textContent = '';
    return true;
}

// Function to validate password
function validatePassword(input) {
    const value = input.value;
    const errorElement = input.nextElementSibling;
    
    if (value.length < 8) {
        errorElement.textContent = 'Password must be at least 8 characters long';
        return false;
    }
    
    // Check for at least one uppercase letter, one lowercase letter, and one number
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/;
    if (!passwordRegex.test(value)) {
        errorElement.textContent = 'Password must include at least one uppercase letter, one lowercase letter, and one number';
        return false;
    }
    
    errorElement.textContent = '';
    return true;
}

// Function to validate confirm password
function validateConfirmPassword(input, passwordInput) {
    const value = input.value;
    const passwordValue = passwordInput.value;
    const errorElement = input.nextElementSibling;
    
    if (value !== passwordValue) {
        errorElement.textContent = 'Passwords do not match';
        return false;
    }
    
    errorElement.textContent = '';
    return true;
}

// Function to validate ID number (South African format)
function validateIDNumber(input) {
    const value = input.value.trim();
    const errorElement = input.nextElementSibling;
    
    if (!value) {
        errorElement.textContent = 'ID number is required';
        return false;
    }
    
    // South African ID number validation (13 digits)
    if (!/^\d{13}$/.test(value)) {
        errorElement.textContent = 'Please enter a valid 13-digit ID number';
        return false;
    }
    
    errorElement.textContent = '';
    return true;
}

// Function to validate phone number
function validatePhoneNumber(input) {
    const value = input.value.trim();
    const errorElement = input.nextElementSibling;
    
    if (!value) {
        errorElement.textContent = 'Phone number is required';
        return false;
    }
    
    // South African phone number validation
    // Accepts formats: 0721234567, 072 123 4567, +27 72 123 4567, etc.
    const phoneRegex = /^(\+27|0)[6-8][0-9]\s?[0-9]{3}\s?[0-9]{4}$/;
    if (!phoneRegex.test(value)) {
        errorElement.textContent = 'Please enter a valid South African phone number';
        return false;
    }
    
    errorElement.textContent = '';
    return true;
}

// Function to validate postal code
function validatePostalCode(input) {
    const value = input.value.trim();
    const errorElement = input.nextElementSibling;
    
    if (!value) {
        errorElement.textContent = 'Postal code is required';
        return false;
    }
    
    // South African postal code format (4 digits)
    if (!/^\d{4}$/.test(value)) {
        errorElement.textContent = 'Please enter a valid 4-digit postal code';
        return false;
    }
    
    errorElement.textContent = '';
    return true;
}

// Function to validate file input
function validateFileInput(input) {
    const errorElement = input.parentElement.nextElementSibling;
    
    if (input.files.length === 0) {
        errorElement.textContent = 'Please select a file';
        return false;
    }
    
    const file = input.files[0];
    const fileType = file.type;
    const fileSize = file.size;
    
    // Check file type (allow only images)
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
    if (!allowedTypes.includes(fileType)) {
        errorElement.textContent = 'Please upload a valid image file (JPEG, PNG)';
        return false;
    }
    
    // Check file size (max 5MB)
    const maxSizeInBytes = 5 * 1024 * 1024; // 5MB
    if (fileSize > maxSizeInBytes) {
        errorElement.textContent = 'File size must be less than 5MB';
        return false;
    }
    
    errorElement.textContent = '';
    return true;
}

// Attach validation to form elements when DOM loads
document.addEventListener('DOMContentLoaded', function() {
    // Registration form validation
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        const fullNameInput = document.getElementById('fullName');
        const emailInput = document.getElementById('email');
        const passwordInput = document.getElementById('password');
        const confirmPasswordInput = document.getElementById('confirmPassword');
        
        if (fullNameInput) {
            fullNameInput.addEventListener('blur', () => validateFullName(fullNameInput));
        }
        
        if (emailInput) {
            emailInput.addEventListener('blur', () => validateEmail(emailInput));
        }
        
        if (passwordInput) {
            passwordInput.addEventListener('blur', () => validatePassword(passwordInput));
        }
        
        if (confirmPasswordInput && passwordInput) {
            confirmPasswordInput.addEventListener('blur', () => validateConfirmPassword(confirmPasswordInput, passwordInput));
        }
        
        registerForm.addEventListener('submit', function(e) {
            let isValid = true;
            
            if (fullNameInput && !validateFullName(fullNameInput)) {
                isValid = false;
            }
            
            if (emailInput && !validateEmail(emailInput)) {
                isValid = false;
            }
            
            if (passwordInput && !validatePassword(passwordInput)) {
                isValid = false;
            }
            
            if (confirmPasswordInput && !validateConfirmPassword(confirmPasswordInput, passwordInput)) {
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    }
    
    // User form validation (for resident, leader, police)
    const userForms = document.querySelectorAll('#residentForm, #leaderForm, #policeForm');
    
    userForms.forEach(form => {
        if (form) {
            const idNumberInput = form.querySelector('#idNumber');
            const phoneInput = form.querySelector('#phoneNumber');
            const postalCodeInput = form.querySelector('#postalCode');
            const idPhotoInput = form.querySelector('#idPhoto');
            
            if (idNumberInput) {
                idNumberInput.addEventListener('blur', () => validateIDNumber(idNumberInput));
            }
            
            if (phoneInput) {
                phoneInput.addEventListener('blur', () => validatePhoneNumber(phoneInput));
            }
            
            if (postalCodeInput) {
                postalCodeInput.addEventListener('blur', () => validatePostalCode(postalCodeInput));
            }
            
            if (idPhotoInput) {
                idPhotoInput.addEventListener('change', () => validateFileInput(idPhotoInput));
            }
            
            form.addEventListener('submit', function(e) {
                let isValid = true;
                
                if (idNumberInput && !validateIDNumber(idNumberInput)) {
                    isValid = false;
                }
                
                if (phoneInput && !validatePhoneNumber(phoneInput)) {
                    isValid = false;
                }
                
                if (postalCodeInput && !validatePostalCode(postalCodeInput)) {
                    isValid = false;
                }
                
                if (idPhotoInput && !validateFileInput(idPhotoInput)) {
                    isValid = false;
                }
                
                if (!document.getElementById('termsCheck').checked) {
                    const termsError = document.getElementById('termsError');
                    termsError.textContent = 'You must accept the terms and conditions';
                    isValid = false;
                } else {
                    document.getElementById('termsError').textContent = '';
                }
                
                if (!isValid) {
                    e.preventDefault();
                }
            });
        }
    });
    
    // Login form validation
    const loginForm = document.getElementById('loginForm');
    
    if (loginForm) {
        const loginEmailInput = document.getElementById('loginEmail');
        const loginPasswordInput = document.getElementById('loginPassword');
        
        if (loginEmailInput) {
            loginEmailInput.addEventListener('blur', () => validateEmail(loginEmailInput));
        }
        
        if (loginPasswordInput) {
            loginPasswordInput.addEventListener('blur', () => {
                const value = loginPasswordInput.value;
                const errorElement = loginPasswordInput.nextElementSibling;
                
                if (!value) {
                    errorElement.textContent = 'Password is required';
                    return false;
                }
                
                errorElement.textContent = '';
                return true;
            });
        }
        
        loginForm.addEventListener('submit', function(e) {
            let isValid = true;
            
            if (loginEmailInput && !validateEmail(loginEmailInput)) {
                isValid = false;
            }
            
            if (loginPasswordInput && !loginPasswordInput.value) {
                loginPasswordInput.nextElementSibling.textContent = 'Password is required';
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault();
            }
            // Allow form submission to server if valid
        });
    }
});
