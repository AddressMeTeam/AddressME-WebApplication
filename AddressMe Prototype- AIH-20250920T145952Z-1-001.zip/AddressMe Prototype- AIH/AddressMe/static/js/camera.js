// Camera functionality for identity verification
document.addEventListener('DOMContentLoaded', function() {
    const videoElement = document.getElementById('video');
    const canvasElement = document.getElementById('canvas');
    const captureBtn = document.getElementById('captureBtn');
    const retakeBtn = document.getElementById('retakeBtn');
    const submitBtn = document.getElementById('submitVerification');
    const statusElement = document.getElementById('cameraStatus');
    let stream;
    
    // Check if we're on the verification page
    if (!videoElement || !canvasElement) {
        return;
    }
    
    // Initialize camera
    initCamera();
    
    function initCamera() {
        // Check if browser supports getUserMedia
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            statusElement.textContent = 'Your browser does not support camera access. Please use a modern browser.';
            statusElement.classList.add('text-danger');
            return;
        }
        
        // Request camera access
        navigator.mediaDevices.getUserMedia({ video: true, audio: false })
            .then(function(mediaStream) {
                stream = mediaStream;
                videoElement.srcObject = mediaStream;
                videoElement.play();
                
                statusElement.textContent = 'Camera is active. Position your face in the frame and click "Capture Photo".';
                statusElement.classList.remove('text-danger');
                statusElement.classList.add('text-success');
                
                // Enable capture button
                captureBtn.disabled = false;
            })
            .catch(function(error) {
                console.error('Error accessing camera:', error);
                statusElement.textContent = 'Error accessing camera: ' + error.message;
                statusElement.classList.add('text-danger');
            });
    }
    
    // Capture photo
    captureBtn.addEventListener('click', function() {
        // Get canvas context
        const context = canvasElement.getContext('2d');
        
        // Set canvas dimensions to match video
        canvasElement.width = videoElement.videoWidth;
        canvasElement.height = videoElement.videoHeight;
        
        // Draw current video frame to canvas
        context.drawImage(videoElement, 0, 0, canvasElement.width, canvasElement.height);
        
        // Convert canvas to image data URL
        const imageDataURL = canvasElement.toDataURL('image/png');
        
        // Store image in local storage (in a real app, this would be sent to a server)
        localStorage.setItem('verificationPhoto', imageDataURL);
        
        // Show the photo and retake/submit buttons
        videoElement.style.display = 'none';
        canvasElement.style.display = 'block';
        captureBtn.style.display = 'none';
        retakeBtn.style.display = 'inline-block';
        submitBtn.disabled = false;
        
        statusElement.textContent = 'Photo captured. You can retake or proceed with this photo.';
    });
    
    // Retake photo
    retakeBtn.addEventListener('click', function() {
        // Show video and hide canvas
        videoElement.style.display = 'block';
        canvasElement.style.display = 'none';
        captureBtn.style.display = 'inline-block';
        retakeBtn.style.display = 'none';
        submitBtn.disabled = true;
        
        statusElement.textContent = 'Camera is active. Position your face in the frame and click "Capture Photo".';
    });
    
    // Submit verification - simplified for demo
    submitBtn.addEventListener('click', function() {
        // Show loading state but no image processing
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
        submitBtn.disabled = true;
        
        // Set a dummy value for the hidden input
        document.getElementById('faceImageData').value = 'demo_image_data';
        
        // Submit the form immediately
        submitBtn.form.submit();
    });
    
    // Clean up when leaving the page
    window.addEventListener('beforeunload', function() {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
        }
    });
});
