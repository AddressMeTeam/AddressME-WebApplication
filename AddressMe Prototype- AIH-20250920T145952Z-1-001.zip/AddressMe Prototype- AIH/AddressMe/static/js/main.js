// Global state management
const addressMeApp = {
    currentUser: null,
    userType: null,
    formData: {},
    
    // Initialize the application
    init: function() {
        // Check for existing user data in localStorage
        const userData = localStorage.getItem('addressMeUser');
        if (userData) {
            this.currentUser = JSON.parse(userData);
        }
        
        // Initialize page-specific functionality
        this.initCurrentPage();
    },
    
    // Initialize functionality based on current page
    initCurrentPage: function() {
        const currentPath = window.location.pathname;
        
        // Landing page
        if (currentPath === '/' || currentPath.includes('index.html')) {
            this.initLandingPage();
        }
        // Registration page 
        else if (currentPath.includes('register')) {
            this.initRegistrationPage();
        }
        // User type specific forms
        else if (currentPath.includes('resident_form')) {
            this.initResidentForm();
        }
        else if (currentPath.includes('leader_form')) {
            this.initLeaderForm();
        }
        else if (currentPath.includes('police_form')) {
            this.initPoliceForm();
        }
        // Verification page
        else if (currentPath.includes('verification')) {
            this.initVerificationPage();
        }
        // Confirmation page
        else if (currentPath.includes('confirmation')) {
            this.initConfirmationPage();
        }
        // Login page
        else if (currentPath.includes('login')) {
            this.initLoginPage();
        }
    },
    
    // Landing page functionality
    initLandingPage: function() {
        // Nothing specific needed for landing page
    },
    
    // Registration page functionality
    initRegistrationPage: function() {
        // Handle user type selection
        const userTypeOptions = document.querySelectorAll('.user-type-option');
        const userTypeInput = document.getElementById('userType');
        const registerForm = document.getElementById('registerForm');
        const submitBtn = document.getElementById('registerSubmitBtn');
        
        // Explicitly set a default user type (resident) to avoid blank submissions
        userTypeInput.value = 'resident';
        
        userTypeOptions.forEach(option => {
            option.addEventListener('click', function() {
                // Remove selected class from all options
                userTypeOptions.forEach(opt => opt.classList.remove('selected'));
                
                // Add selected class to clicked option
                this.classList.add('selected');
                
                // Update hidden input value
                userTypeInput.value = this.dataset.type;
                console.log("Selected user type: " + userTypeInput.value);
                
                // Enable submit button
                submitBtn.disabled = false;
            });
        });
        
        // Add the resident class to the first option by default
        if (userTypeOptions.length > 0) {
            userTypeOptions[0].classList.add('selected');
            submitBtn.disabled = false;
        }
        
        if (registerForm) {
            registerForm.addEventListener('submit', function(e) {
                // Additional check to ensure userType is set before submission
                console.log("Form submitted with userType: " + userTypeInput.value);
                
                if (!userTypeInput.value) {
                    e.preventDefault();
                    alert("Please select a user type before proceeding.");
                    return false;
                }
                
                // Basic validation
                if (!registerForm.checkValidity()) {
                    e.preventDefault();
                    registerForm.classList.add('was-validated');
                    return false;
                }
                
                // Allow natural form submission if all is valid
                return true;
            });
        }
    },
    
    // Resident form functionality
    initResidentForm: function() {
        this.initFormValidation('residentForm');
        
        // Municipality dropdown population
        populateMunicipalities();
    },
    
    // Leader form functionality
    initLeaderForm: function() {
        this.initFormValidation('leaderForm');
        
        // Municipality dropdown population
        populateMunicipalities();
    },
    
    // Police form functionality
    initPoliceForm: function() {
        this.initFormValidation('policeForm');
        
        // Municipality dropdown population
        populateMunicipalities();
    },
    
    // Generic form validation setup
    initFormValidation: function(formId) {
        const form = document.getElementById(formId);
        if (form) {
            // Add a direct submit function to ensure the form always works
            form.onsubmit = function(e) {
                console.log("Form " + formId + " is being submitted");
                
                // Basic validation only
                if (!form.checkValidity()) {
                    e.preventDefault();
                    form.classList.add('was-validated');
                    console.log("Form validation failed");
                    return false;
                }
                
                // Form is valid, log and allow submission
                console.log("Form is valid, submitting to server");
                return true;
            };
            
            // Add click handler for the submit button as a backup
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.addEventListener('click', function() {
                    console.log("Submit button clicked for " + formId);
                    
                    // If the form is valid, force submit
                    if (form.checkValidity()) {
                        console.log("Form is valid, forcing submission");
                        form.submit();
                    } else {
                        console.log("Form validation failed on button click");
                        form.classList.add('was-validated');
                    }
                });
            }
            
            // Custom file input handling
            const fileInput = form.querySelector('.custom-file-input');
            if (fileInput) {
                fileInput.addEventListener('change', function() {
                    // Get the file name
                    let fileName = '';
                    if (this.files && this.files.length > 0) {
                        fileName = this.files[0].name;
                    }
                    
                    // Update the label with the file name
                    const label = this.nextElementSibling;
                    if (label) {
                        label.innerHTML = fileName || 'Choose file';
                    }
                });
            }
        }
    },
    
    // Verification page functionality
    initVerificationPage: function() {
        // Camera functionality initialization is handled in camera.js
    },
    
    // Confirmation page functionality
    initConfirmationPage: function() {
        // Using server-side data now, no need to populate from localStorage
        console.log("Confirmation page loaded with server-provided user data");
    },
    
    // Login page functionality
    initLoginPage: function() {
        // Login form handling - allow server-side form submission
        const loginForm = document.getElementById('loginForm');
        
        // No longer preventing default form submission
        // Now the form will submit to the server-side route
    },
    
    // Helper function to capitalize first letter
    capitalizeFirstLetter: function(string) {
        if (!string) return '';
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
};

// Helper function to populate municipality dropdown
function populateMunicipalities() {
    const municipalitySelect = document.getElementById('municipality');
    if (!municipalitySelect) return;
    
    // Sample list of municipalities (in a real app, this would come from an API)
    const municipalities = [
        "Buffalo City",
        "City of Cape Town",
        "City of Johannesburg",
        "City of Tshwane",
        "Ekurhuleni",
        "eThekwini",
        "Mangaung",
        "Nelson Mandela Bay",
        "Emfuleni",
        "Mogale City",
        "Msunduzi",
        "Polokwane",
        "Rustenburg",
        "Sol Plaatje",
        "uMhlathuze"
    ];
    
    // Sort alphabetically
    municipalities.sort();
    
    // Add options to select
    municipalities.forEach(municipality => {
        const option = document.createElement('option');
        option.value = municipality;
        option.textContent = municipality;
        municipalitySelect.appendChild(option);
    });
}

// Initialize the app when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    addressMeApp.init();
});
