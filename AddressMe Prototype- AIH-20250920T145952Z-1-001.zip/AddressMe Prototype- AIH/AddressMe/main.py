import os
from app import app  # noqa: F401

# Basic structure for WSGI servers (PythonAnywhere, etc.) to import
application = app

if __name__ == '__main__':
    # For local development
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
